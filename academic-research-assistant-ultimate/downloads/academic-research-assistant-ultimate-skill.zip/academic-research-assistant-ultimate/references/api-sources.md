# 國際 API 來源摘要
- OpenAlex: https://api.openalex.org ; works/authors/sources/institutions/topics. 無 key 可做基礎請求；大規模與 cursor paging 使用 key。官方 MCP `https://mcp.openalex.org/mcp` 是 Streamable HTTP/OAuth，先確認 Host 支援。
- Semantic Scholar: https://api.semanticscholar.org/graph/v1 ; API key 使用 `x-api-key`；按官方配額與回應限速。
- Crossref: https://api.crossref.org ; DOI/works metadata，建議 `mailto` polite pool；metadata 是會員提交且可能不完整。
- Unpaywall: https://api.unpaywall.org/v2/{doi}?email=... ; DOI 查詢需 email。只使用回傳的合法 OA locations，保留 license/host。
- Europe PMC: https://www.ebi.ac.uk/europepmc/webservices/rest ; 搜尋、DOI/PMID/PMCID及可用全文 XML。
- PubMed E-utilities: https://eutils.ncbi.nlm.nih.gov/entrez/eutils ; 遵守 NCBI API key 與請求限制。
- arXiv API: https://export.arxiv.org/api/query ; 預印本應標明非必然同儕審查。
- DOAJ: https://doaj.org/api/v2 ; 期刊與文章公開 metadata。
- DataCite: https://api.datacite.org ; DOI 與研究資料 metadata。

供應商政策/限速可能變更；部署前重查官方文件。API metadata 可用不代表全文授權。
