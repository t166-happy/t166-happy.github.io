# 合規擷取政策
自動來源順序：官方開放資料→官方書目匯出→明確允許自動化的公開頁面→已授權介接→使用者匯入。檢查 robots.txt、terms、頻率與資料授權；robots 不是授權替代品。網域白名單、HTTPS、拒絕私有/loopback/link-local IP 和 DNS rebinding/redirect；每來源限速、快取、退避、可續跑、記錄請求。403/429/驗證碼/付費牆/登入要求即停止，不換代理、不偽裝 User-Agent。全文必須有可記錄的 OA/license/permission，否則只存 metadata 和連結。
