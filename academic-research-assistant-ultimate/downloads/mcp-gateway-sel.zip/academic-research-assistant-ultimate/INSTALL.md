# 安裝與部署
## Skill
本次更新包通過 Skill 格式驗證；未將此更新版安裝至帳號，也未確認原有專案層級版本在新工作階段會自動觸發。支援本地 Skills 的客戶端：將專案資料夾放入該客戶端文件指定的 skills 目錄，重啟後使用「學術論文研究助手 Ultimate」觸發。ChatGPT 官方帳號安裝路徑需依當前產品 UI/管理者政策確認。
## MCP
請依 [Gateway README](gateway/README.md) 在本機啟動，另開終端執行驗收。若要讓 ChatGPT 帳號跨對話使用，另外配置 Secure MCP Tunnel 或經授權的 HTTPS 入口。
## Zotero
建立 Zotero API key 並僅授予必要讀寫權限，將 API key 與 User ID 存入 secret manager。先做讀取與重複檢查，新增/批次修改前需使用者明確確認。此包不索取或保存憑證。
