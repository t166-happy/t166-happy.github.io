> 以下為前版歷史紀錄。最新狀態請以 [SEL 驗收報告](evidence/SEL-VALIDATION.md) 為準。

# Implementation / verification status (2026-11-20)

| Component | Status | Evidence/limitation |
|---|---|---|
| Skill content | Built | SKILL.md and references included; not installed into ChatGPT account (no installation tool exposed) |
| OpenAlex REST | Connector implemented | Not exercised from Python runtime; execution network was restricted; official docs checked |
| OpenAlex MCP | Verified endpoint/documentation only | Official server uses Streamable HTTP/OAuth; not linked to ChatGPT; ChatGPT support not confirmed |
| Crossref | Connector implemented | Public API requires no key; polite mailto optional; not runtime-tested |
| Semantic Scholar | Connector implemented | API key optional/quotas apply; not runtime-tested |
| Unpaywall/Europe PMC | Connectors implemented | Unpaywall requires email; not runtime-tested |
| Taiwan NDLTD | CSV loader implemented | Dataset 14024 confirmed on data.gov.tw as CSV, OGL 1.0, free; no actual resource fetched |
| Airiti / TPL / TCI-HSS | Disabled | No credential/verified reusable API contract in this run; manual official export workflow documented |
| Crawler / PDF | Policy and basic modules | No arbitrary crawler; downloader requires license evidence; PDF text extraction implemented but OCR not |
| Zotero | Write connector implemented | No key/OAuth; no test write performed |
| MCP Gateway | MVP implemented | search_papers, verify_metadata, search_semantic_scholar, inspect_source_policy; other requested tools not implemented |
| Exports | CSV/JSON/XLSX/DOCX/PDF helpers | dependencies not installed/run in this environment; no artifact generation verified |
| End-to-end topic acceptance | Not performed | No real API fetch or PDF input in runtime; all live integration tests blocked by network/credentials |
| Tests | Test suite included | Results recorded in TEST_REPORT.md; no fictitious results |
| Deployment | Not done | No persistent host/domain or account MCP configuration authority exposed |

Known missing: OpenAlex author/institution/citation tools; Unpaywall PDF authorization workflow integration; complete Taiwan connectors; crawler robots/terms ingestion; OCR/table extraction; article analysis/matrix and report-specific MCP tools; Zotero duplicate/read/collection operations and OAuth; comprehensive validation suite.
