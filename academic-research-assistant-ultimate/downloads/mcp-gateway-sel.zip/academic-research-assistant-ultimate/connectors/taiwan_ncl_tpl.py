"""Taiwan Periodical Literature System adapter; disabled pending verified open API/export."""
ENABLED=False
STATUS="Verify NCL formal API/open dataset terms before enabling. Manual official search/export is supported."
def search(*args,**kwargs): raise RuntimeError(STATUS)
