"""Repository OAI-PMH adapters must be configured per institution after terms review."""
def validate_config(config):
    required={"base_url","protocol","license_url","allowed_metadata_formats"}
    missing=required-set(config)
    if missing: raise ValueError(f"Missing repository policy fields: {sorted(missing)}")
    if not config["base_url"].startswith("https://"): raise ValueError("HTTPS required")
    return True
