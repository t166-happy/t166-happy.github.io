"""Unpaywall DOI lookup; requires a registered contact email."""
import os,httpx
async def find_oa(doi:str):
    email=os.getenv("UNPAYWALL_EMAIL")
    if not email: raise RuntimeError("UNPAYWALL_EMAIL is required; no OA query made")
    doi=doi.removeprefix("https://doi.org/")
    async with httpx.AsyncClient(timeout=20) as c:
        r=await c.get(f"https://api.unpaywall.org/v2/{doi}",params={"email":email}); r.raise_for_status(); d=r.json()
        return {"doi":d.get("doi"),"oa_status":d.get("oa_status"),"best_oa_location":d.get("best_oa_location"),"oa_locations":d.get("oa_locations",[])}
