"""Zotero Web API v3: opt-in write; credentials are environment-only."""
import os,httpx
async def create_item(item:dict):
    uid=os.getenv("ZOTERO_USER_ID"); key=os.getenv("ZOTERO_API_KEY"); typ=os.getenv("ZOTERO_LIBRARY_TYPE","user")
    if not uid or not key: raise RuntimeError("Zotero credentials not configured")
    if not item.get("itemType"): raise ValueError("itemType required")
    # Caller must obtain explicit user confirmation before invoking this write function.
    url=f"https://api.zotero.org/{typ}s/{uid}/items"
    async with httpx.AsyncClient(timeout=25,headers={"Zotero-API-Key":key,"Zotero-API-Version":"3"}) as c:
        r=await c.post(url,json=[item]); r.raise_for_status(); return r.json()
