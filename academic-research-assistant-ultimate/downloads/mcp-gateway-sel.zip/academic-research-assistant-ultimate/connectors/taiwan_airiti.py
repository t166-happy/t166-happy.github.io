"""Airiti adapter intentionally disabled pending a documented institutional/vendor API grant."""
ENABLED=False
STATUS="No credentials or verified generally available API contract configured. Use official export (RIS/BibTeX/CSV) or user-supplied files; never automate login/paid access."
def search(*args,**kwargs): raise RuntimeError(STATUS)
