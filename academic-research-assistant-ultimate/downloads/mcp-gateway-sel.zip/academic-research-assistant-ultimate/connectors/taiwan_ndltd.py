"""Government open-data NDLTD connector stub: ingest official CSV resource URL."""
import httpx,csv,io
async def load_csv(url:str):
    if not url.startswith("https://data.gov.tw/") and "data.gov.tw" not in url: raise ValueError("Only official data.gov.tw dataset resource URLs accepted")
    async with httpx.AsyncClient(timeout=60,follow_redirects=False) as c:
        r=await c.get(url); r.raise_for_status()
        if "text/csv" not in r.headers.get("content-type","") and not url.lower().endswith(".csv"): raise ValueError("Resource is not identified as CSV")
        return list(csv.DictReader(io.StringIO(r.text)))
