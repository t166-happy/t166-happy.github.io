"""Semantic Scholar Academic Graph search."""
import os,httpx
async def search_papers(query:str,limit:int=10):
    headers={}
    if os.getenv("SEMANTIC_SCHOLAR_API_KEY"): headers["x-api-key"]=os.environ["SEMANTIC_SCHOLAR_API_KEY"]
    params={"query":query,"limit":min(max(limit,1),100),"fields":"paperId,title,authors,year,abstract,venue,citationCount,referenceCount,externalIds,openAccessPdf"}
    async with httpx.AsyncClient(timeout=25,headers=headers) as c:
        r=await c.get("https://api.semanticscholar.org/graph/v1/paper/search",params=params); r.raise_for_status(); return r.json()
