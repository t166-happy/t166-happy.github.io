"""OpenAlex REST connector; reads API key from environment."""
import os, httpx
BASE="https://api.openalex.org"
async def search_works(query:str, per_page:int=10):
    params={"search":query,"per_page":min(max(per_page,1),100),"select":"id,doi,title,publication_year,authorships,cited_by_count,open_access,primary_location,biblio"}
    if os.getenv("OPENALEX_API_KEY"): params["api_key"]=os.environ["OPENALEX_API_KEY"]
    async with httpx.AsyncClient(timeout=25,follow_redirects=False) as c:
        r=await c.get(BASE+"/works",params=params); r.raise_for_status(); return r.json()
