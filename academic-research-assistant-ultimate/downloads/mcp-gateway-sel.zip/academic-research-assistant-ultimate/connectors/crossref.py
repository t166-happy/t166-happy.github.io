"""Crossref REST metadata and DOI verification."""
import os,re,httpx
from urllib.parse import quote
BASE="https://api.crossref.org"
async def query_works(query:str,rows:int=10):
    params={"query.bibliographic":query,"rows":min(max(rows,1),100)}
    if os.getenv("CROSSREF_MAILTO"): params["mailto"]=os.environ["CROSSREF_MAILTO"]
    async with httpx.AsyncClient(timeout=25,headers={"User-Agent":"academic-research-assistant-ultimate/1.0"}) as c:
        r=await c.get(BASE+"/works",params=params); r.raise_for_status(); return r.json()["message"]["items"]
async def verify_doi(doi:str):
    doi=doi.strip().removeprefix("https://doi.org/")
    if not re.fullmatch(r"10\.\d{4,9}/[^\s]+",doi) or any(p in {".",".."} for p in doi.split("/")):
        return {"verified":False,"reason":"invalid_doi"}
    async with httpx.AsyncClient(timeout=20) as c:
        r=await c.get(BASE+"/works/"+quote(doi,safe="/"))
        if r.status_code==404:return {"verified":False,"doi":doi}
        r.raise_for_status(); return {"verified":True,"metadata":r.json()["message"]}
