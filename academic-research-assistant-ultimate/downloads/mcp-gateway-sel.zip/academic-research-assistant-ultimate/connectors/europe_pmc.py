"""Europe PMC public REST search connector."""
import httpx
async def search(query:str,page_size:int=10):
    async with httpx.AsyncClient(timeout=25) as c:
        r=await c.get("https://www.ebi.ac.uk/europepmc/webservices/rest/search",params={"query":query,"format":"json","pageSize":min(max(page_size,1),100)}); r.raise_for_status(); return r.json()
