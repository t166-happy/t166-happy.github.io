"""TCI-HSS adapter disabled pending data license/institutional access."""
ENABLED=False
STATUS="No authorized API credentials configured; use official UI/export and user-supplied metadata."
def search(*args,**kwargs): raise RuntimeError(STATUS)
