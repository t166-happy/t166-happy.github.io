"""Government Open Data dataset metadata helper."""
DATASET_URL="https://data.gov.tw/dataset/14024"
DATASET_ID="14024"
LICENSE="Open Government Data License, version 1.0 (verify current resource metadata before reuse)"
