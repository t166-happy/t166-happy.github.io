"""ERIC (U.S. Department of Education) public search API."""
import httpx

async def search(query: str, limit: int = 10) -> dict:
    async with httpx.AsyncClient(timeout=20, follow_redirects=False) as client:
        response = await client.get("https://api.ies.ed.gov/eric/", params={
            "search": query, "format": "json", "rows": limit,
            "fields": "id,title,author,publicationdateyear,description,source,peerreviewed",
        })
        response.raise_for_status()
        return response.json()["response"]
