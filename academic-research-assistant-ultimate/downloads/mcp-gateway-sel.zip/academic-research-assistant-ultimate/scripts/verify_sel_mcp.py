"""Live MCP client verification; requires loopback server to be running."""
import asyncio
import json
import argparse
import httpx
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client

async def main(crawl_url):
    results = {}
    async with httpx.AsyncClient(trust_env=False, timeout=90) as client, streamable_http_client("http://127.0.0.1:8765/mcp", http_client=client) as (read, write, _):
        async with ClientSession(read, write) as session:
            run = await session.initialize()
            results["protocol"] = run.protocolVersion
            results["tools"] = [t.name for t in (await session.list_tools()).tools]
            async def call(name, **kwargs):
                value = await session.call_tool(name, kwargs)
                if value.isError:
                    raise RuntimeError(value.content)
                return value.structuredContent if value.structuredContent is not None else json.loads(value.content[0].text)
            report = await call("search_papers", query="schoolwide social emotional learning school leadership implementation", limit=5,
                                providers=["crossref"])
            for key, item in report["providers"].items():
                data = item.get("data")
                if isinstance(data, list):
                    item["titles"] = [(r.get("title") or [""])[0] for r in data]
                elif isinstance(data, dict):
                    records = data.get("results", data.get("resultList", {}).get("result", data.get("data", [])))
                    item["titles"] = [r.get("title") for r in records]
                item.pop("data", None)
            results["mcp_api_search"] = report
            eric = await call("search_papers", query='"social emotional learning" AND ("school leadership" OR "schoolwide")', providers=["eric"], limit=5)
            provider = eric["providers"]["eric"]
            data = provider.pop("data", {})
            results["eric"] = {**provider, "query": eric["query"], "matches": data.get("numFound"),
                               "records": [{k: r.get(k) for k in ("id", "title")} for r in data.get("docs", [])]}
            epmc = await call("search_papers", query='(TITLE_ABS:"social and emotional learning" OR TITLE_ABS:"social emotional learning") AND TITLE_ABS:schoolwide', providers=["europe_pmc"], limit=8)
            ep = epmc["providers"]["europe_pmc"]
            epdata = ep.pop("data", {})
            results["europe_pmc"] = {**ep, "query": epmc["query"], "matches": epdata.get("hitCount"),
                "records": [{k:r.get(k) for k in ("title","doi")} for r in epdata.get("resultList",{}).get("result",[])]}
            results["doi"] = {}
            for doi in ("10.1016/j.jsp.2023.01.006", "10.1016/j.sel.2025.100156"):
                payload = await call("verify_metadata", doi=doi)
                doc = payload.pop("data", {})
                results["doi"][doi] = {**payload, "verified": doc.get("verified"),
                                       "title": doc.get("metadata", {}).get("title")}
            assert results["mcp_api_search"]["providers"]["crossref"]["status"] == "ok"
            assert results["eric"]["status"] == "ok" and results["eric"]["matches"] > 0
            assert results["europe_pmc"]["status"] == "ok" and results["europe_pmc"]["matches"] > 0
            assert all(item["verified"] for item in results["doi"].values())
            if crawl_url:
                results["crawler_allow"] = await call("crawl_public_bibliography", url=crawl_url)
                results["crawler_deny"] = await call("crawl_public_bibliography", url="https://example.invalid/paper")
                assert results["crawler_allow"]["status"] == "ok"
                assert results["crawler_deny"]["status"] == "blocked"
    print(json.dumps(results, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--crawl-url")
    asyncio.run(main(parser.parse_args().crawl_url))
