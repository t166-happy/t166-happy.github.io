"""Text-layer PDF extraction with page provenance; OCR is intentionally opt-in."""
def extract_pdf(path):
    import fitz
    doc=fitz.open(path); pages=[]
    for i,p in enumerate(doc): pages.append({"page":i+1,"text":p.get_text("text").strip()})
    return {"pages":pages,"ocr_used":False,"needs_ocr":not any(x["text"] for x in pages)}
