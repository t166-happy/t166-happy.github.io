"""Normalize common scholarly metadata without inventing fields."""
import re,unicodedata
def norm_doi(value):
    if not value:return None
    return re.sub(r"^https?://(dx\.)?doi.org/","",str(value).strip(),flags=re.I).lower().rstrip(".")
def normalize(item):
    d=dict(item); d["doi"]=norm_doi(d.get("doi") or d.get("DOI"))
    for k in ("title","abstract"):
        if d.get(k):d[k]=unicodedata.normalize("NFC",str(d[k])).strip()
    return d
