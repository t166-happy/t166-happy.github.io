"""Stable duplicate collapse using DOI then normalized title/year."""
import re
from normalize_metadata import norm_doi
def key(x):
    doi=norm_doi(x.get("doi"))
    if doi:return "doi:"+doi
    title=re.sub(r"\W+","",str(x.get("title","")).lower())
    return f"title:{title}:{x.get('year') or x.get('publication_year') or ''}"
def deduplicate(items):
    seen={}; out=[]
    for x in items:
        k=key(x)
        if k not in seen: seen[k]=len(out); out.append(dict(x))
        else:
            old=out[seen[k]]
            for a,b in x.items():
                if old.get(a) in (None,"") and b not in (None,""):old[a]=b
    return out
