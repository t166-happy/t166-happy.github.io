"""Export metadata to CSV/JSON/XLSX/DOCX/PDF when optional dependencies exist."""
import csv,json
from pathlib import Path
def export_json(items,path):Path(path).write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding="utf-8")
def export_csv(items,path):
    cols=list(dict.fromkeys(k for x in items for k in x))
    with open(path,"w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=cols); w.writeheader(); w.writerows(items)
def export_xlsx(items,path):
    import pandas as pd
    pd.DataFrame(items).to_excel(path,index=False)
def export_docx(title,body,path):
    from docx import Document
    d=Document(); d.add_heading(title,0)
    for line in body.splitlines(): d.add_paragraph(line)
    d.save(path)
def export_pdf(title,body,path):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    c=canvas.Canvas(path,pagesize=A4); c.setTitle(title); y=800
    for line in (title+"\n\n"+body).splitlines():
        c.drawString(45,y,line[:110]); y-=16
        if y<50:c.showPage();y=800
    c.save()
