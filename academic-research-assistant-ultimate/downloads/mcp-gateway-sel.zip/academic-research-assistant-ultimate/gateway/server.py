"""Academic Research MCP Gateway; loopback-only by default."""
import asyncio
import logging
from typing import Annotated, Literal
import httpx
from pydantic import Field
from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations
from crawler import public_metadata
from connectors import crossref, eric, europe_pmc, openalex, semantic_scholar
from connectors.taiwan_airiti import STATUS as AIRITI_STATUS
from connectors.taiwan_ncl_tpl import STATUS as TPL_STATUS
from connectors.taiwan_tci import STATUS as TCI_STATUS

# Do not log HTTP request URLs, which may include upstream API keys.
logging.getLogger("httpx").setLevel(logging.WARNING)
mcp = FastMCP("academic-research-assistant-ultimate", host="127.0.0.1", port=8765,
              stateless_http=True, json_response=True)
Provider = Literal["crossref", "eric", "openalex", "europe_pmc", "semantic_scholar"]
Query = Annotated[str, Field(min_length=1, max_length=500)]
Limit = Annotated[int, Field(ge=1, le=20)]
# Provider names, not user-supplied URLs; do not retry a denied or rate-limited source.
SEARCH = {"crossref": crossref.query_works, "eric": eric.search,
          "openalex": openalex.search_works, "europe_pmc": europe_pmc.search,
          "semantic_scholar": semantic_scholar.search_papers}

async def _result(fn, *args):
    try:
        return {"status": "ok", "data": await fn(*args)}
    except httpx.HTTPStatusError as exc:
        return {"status": "http_error", "http_status": exc.response.status_code,
                "retry_after": exc.response.headers.get("Retry-After")}
    except httpx.RequestError:
        return {"status": "connection_error"}
    except (ValueError, KeyError, TypeError):
        return {"status": "invalid_upstream_response"}

@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True))
async def search_papers(query: Query, limit: Limit = 10,
                        providers: list[Provider] | None = None) -> dict:
    """Search official scholarly APIs; report each provider independently. Results are metadata or abstracts, not full text."""
    selected = list(dict.fromkeys(providers if providers is not None else ["crossref", "eric", "openalex"]))
    results = await asyncio.gather(*(_result(SEARCH[key], query, limit) for key in selected))
    return {"query": query, "providers": dict(zip(selected, results))}

@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True))
async def verify_metadata(doi: Annotated[str, Field(min_length=6, max_length=255)]) -> dict:
    """Verify a DOI against Crossref; a miss does not rule out other DOI registries."""
    return await _result(crossref.verify_doi, doi)

@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True))
async def search_semantic_scholar(query: Query, limit: Limit = 10) -> dict:
    """Search Semantic Scholar Academic Graph."""
    return await _result(semantic_scholar.search_papers, query, limit)

@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True))
async def inspect_source_policy(source: str) -> dict:
    """Report activation status of Taiwan commercial/curated sources."""
    info = {"airiti": AIRITI_STATUS, "ncl_tpl": TPL_STATUS, "tci_hss": TCI_STATUS}
    if source.startswith("https://"):
        return public_metadata.inspect_source_policy(source)
    key = source.strip().lower()
    return {"source": key, "enabled": False,
            "reason": info.get(key, "Not configured; verify official API, license, and terms first.")}

@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True))
async def crawl_public_bibliography(url: Annotated[str, Field(max_length=300)]) -> dict:
    """Fetch only explicitly registered public HTML citation metadata; never download PDFs or full text."""
    return await public_metadata.crawl_public_bibliography(url)

if __name__ == "__main__":
    mcp.run(transport="streamable-http")
