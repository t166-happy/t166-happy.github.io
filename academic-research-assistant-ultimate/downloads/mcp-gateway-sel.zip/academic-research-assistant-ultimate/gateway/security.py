"""Gateway security helpers."""
import os
from fastapi import Header,HTTPException
async def require_bearer(authorization:str|None=Header(default=None)):
    token=os.getenv("GATEWAY_BEARER_TOKEN")
    if not token: raise HTTPException(503,"Gateway auth token is not configured")
    if authorization!=f"Bearer {token}": raise HTTPException(401,"Unauthorized")
    return True
