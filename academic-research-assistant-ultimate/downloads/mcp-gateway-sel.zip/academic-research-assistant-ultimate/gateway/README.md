# MCP 執行與部署

## 本機驗收（預設不對外）

在專案根目錄使用 Python 3.10+ 安裝 Gateway 最小依賴：

```sh
python -m pip install -r requirements-gateway.txt
python -m gateway.server
```

另開同一台電腦的終端機，執行：

```sh
python -m scripts.verify_sel_mcp --crawl-url 'https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0336946'
python -m unittest discover -s tests -p test_sel_crawler.py -v
```

Windows PowerShell 的引號也可使用單引號。驗收程式透過 HTTP 連線到 `127.0.0.1:8765/mcp`，實際執行 MCP initialize、tools/list、tools/call，不是直接匯入 server 工具作替代。不要為避免限流重複執行或跨程序增量爬取。若環境有 HTTPS 代理，保留原先允許的代理設定，不要為了接通被拒絕的服務調整路由。

## ChatGPT 帳號層級（不同於本機測試）

本套件不是常駐服務，也不會自行安裝到 ChatGPT。若要私用，建議在有授權且會持續運行的電腦／主機啟動此 loopback server，再依 [Secure MCP Tunnel 官方文件](https://developers.openai.com/api/docs/guides/secure-mcp-tunnels) 建立工作區允許的私有隧道。隧道用戶端與本機 MCP 都必須在線；到 [ChatGPT 外掛](https://chatgpt.com/plugins) 登記，再驗證列示和讀取呼叫。不要把本機網址直接填成公網 Server URL，也不要將此未加應用層驗證的 loopback 服務直接公開。若改走遠端 HTTPS，應在受管理入口配置權限、TLS、速率限制與稽核，並按 [官方連線驗收流程](https://developers.openai.com/plugins/deploy/connect-chatgpt) 在 ChatGPT 重測。

OpenAlex / Semantic Scholar 金鑰僅從環境變數讀取。Unpaywall、Zotero、臺灣來源全文與其他寫入工具不在本次已測通的 MCP 範圍內；不要上傳個資、校內文件或金鑰作為測試字串。
