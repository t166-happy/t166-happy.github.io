"""Input/output schemas shared by MCP tools and CLI."""
from pydantic import BaseModel,Field
class SearchInput(BaseModel): query:str=Field(min_length=2,max_length=500); limit:int=Field(default=10,ge=1,le=100)
class DOIInput(BaseModel): doi:str=Field(min_length=5,max_length=200)
class SourcePolicyOutput(BaseModel): source:str; enabled:bool; reason:str
