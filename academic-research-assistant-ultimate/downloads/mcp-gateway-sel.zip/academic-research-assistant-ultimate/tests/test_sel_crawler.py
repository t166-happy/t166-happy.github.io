import unittest
from urllib.error import URLError

from crawler.public_metadata import LIVE_TEST_URL, _Crawler, inspect_source_policy

ROBOTS = b"User-agent: *\nCrawl-delay: 30\nDisallow: */search\n"
HTML = b"""<!DOCTYPE html><head>
<title>Fixture: Schoolwide SEL</title>
<meta name="citation_title" content="Schoolwide SEL &amp; leadership">
<meta name="citation_author" content="First Author">
<meta name="citation_author" content="Second Author">
<meta name="citation_doi" content="10.1371/journal.pone.0336946">
<meta name="citation_publication_date" content="Dec 11, 2025">
<meta name="citation_pdf_url" content="https://example.org/dont-fetch">
</head><body>Ignore this body.</body>"""


class FakeTransport:
    def __init__(self, *responses):
        self.responses = iter(responses)
        self.calls = []
        self.time = 100

    def fetch(self, url, limit, accept):
        self.calls.append(url)
        response = next(self.responses)
        if isinstance(response, BaseException):
            raise response
        return response

    def clock(self):
        return self.time


class SelCrawlerTests(unittest.TestCase):
    def prepare(self, *responses):
        fixture = FakeTransport(*responses)
        return fixture, _Crawler(fetch=fixture.fetch, clock=fixture.clock)

    def test_allowed_extracts_only_citations_and_caches(self):
        fixture, crawler = self.prepare((200, "text/plain", ROBOTS), (200, "text/html", HTML))
        first = crawler.crawl(LIVE_TEST_URL)
        self.assertEqual(first["status"], "ok")
        self.assertEqual(first["record"]["authors"], ["First Author", "Second Author"])
        self.assertEqual(first["record"]["title"], "Schoolwide SEL & leadership")
        self.assertNotIn("pdf_url", first["record"])
        self.assertEqual(first["minimum_interval_seconds"], 30)
        first["record"]["authors"].clear()
        second = crawler.crawl(LIVE_TEST_URL)
        self.assertTrue(second["cache"])
        second["record"]["authors"].clear()
        self.assertEqual(len(crawler.crawl(LIVE_TEST_URL)["record"]["authors"]), 2)
        self.assertEqual(len(fixture.calls), 2)

    def test_unregistered_never_issues_requests(self):
        fixture, crawler = self.prepare()
        for url in ("https://example.org/", LIVE_TEST_URL + "&other=1", LIVE_TEST_URL + "#x"):
            self.assertEqual(crawler.crawl(url)["reason"], "URL_NOT_ALLOWLISTED")
            self.assertEqual(inspect_source_policy(url)["status"], "blocked")
        self.assertFalse(fixture.calls)

    def test_wildcard_and_deny_are_respected_before_article(self):
        rules = b"User-agent: *\nDisallow: */article\nAllow: /plosone/article\n"
        fixture, crawler = self.prepare((200, "text/plain", rules))
        for _ in range(2):
            self.assertEqual(crawler.crawl(LIVE_TEST_URL)["reason"], "ROBOTS_DISALLOWED")
        self.assertEqual(len(fixture.calls), 1)

    def test_robots_must_be_available_and_plaintext(self):
        for response in ((404, "", b""), (200, "text/html", HTML),
                         (429, "", b""), URLError("test failure")):
            with self.subTest(response=response):
                fixture, crawler = self.prepare(response)
                self.assertEqual(crawler.crawl(LIVE_TEST_URL)["reason"], "ROBOTS_UNAVAILABLE")
                self.assertEqual(len(fixture.calls), 1)

    def test_access_rejection_stops_host_without_retry(self):
        for status in (401, 403, 429):
            with self.subTest(status=status):
                fixture, crawler = self.prepare((200, "text/plain", ROBOTS), (status, "", b""))
                self.assertEqual(crawler.crawl(LIVE_TEST_URL)["http_status"], status)
                self.assertEqual(crawler.crawl(LIVE_TEST_URL)["reason"], "SOURCE_STOPPED")
                self.assertEqual(len(fixture.calls), 2)

    def test_redirect_not_followed_and_article_is_rate_limited(self):
        fixture, crawler = self.prepare((200, "text/plain", ROBOTS), (302, "", b""))
        self.assertEqual(crawler.crawl(LIVE_TEST_URL)["reason"], "REDIRECT_NOT_FOLLOWED")
        self.assertEqual(crawler.crawl(LIVE_TEST_URL)["reason"], "LOCAL_RATE_LIMIT")
        self.assertEqual(len(fixture.calls), 2)

    def test_challenge_or_mismatched_doi_are_not_accepted(self):
        for body in (b"<title>Just a moment...</title>", HTML.replace(b"0336946", b"0000000")):
            with self.subTest(body=body):
                fixture, crawler = self.prepare((200, "text/plain", ROBOTS), (200, "text/html", body))
                self.assertEqual(crawler.crawl(LIVE_TEST_URL)["reason"], "METADATA_NOT_VERIFIED")
                self.assertEqual(crawler.crawl(LIVE_TEST_URL)["reason"], "SOURCE_STOPPED")
                self.assertEqual(len(fixture.calls), 2)


if __name__ == "__main__":
    unittest.main()
