import sys, pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parents[1]/"scripts"))
from normalize_metadata import norm_doi
from deduplicate import deduplicate

def test_doi_normalization(): assert norm_doi("https://doi.org/10.1234/ABC") == "10.1234/abc"
def test_dedup_doi(): assert len(deduplicate([{"doi":"10.1/X","title":"A"},{"doi":"https://doi.org/10.1/x","year":2020}])) == 1
