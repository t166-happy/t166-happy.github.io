> 以下為前版歷史紀錄。最新狀態請以 [SEL 驗收報告](evidence/SEL-VALIDATION.md) 為準。

# Test Report (2026-11-20)

**Scope:** build/package validation only; no live academic API integration claim.

- Python runtime: 3.12.14 reported.
- Official documentation web lookup: successful for Crossref REST, Crossref authentication/rate limits, OpenAlex REST/API key, OpenAlex MCP transport/OAuth, Taiwan NDLTD dataset 14024.
- Runtime HTTP calls: not made. Execution environment network allowlist did not include academic API hosts.
- API keys/OAuth: none configured; Semantic Scholar, Unpaywall and Zotero credential-dependent operations not run.
- Search topic (“2021–2026 Taiwan and international genAI in elementary teaching...”): no live results returned, therefore no real-literature acceptance result is claimed.
- DOI check, dedup, PDF extraction, matrix, citation exports and MCP calls: implementation is partial; tests have not demonstrated end-to-end behavior.
- Authorized PDF download: no actual download attempted; permission gate present. Restricted-source rejection test not executed.
- Skill install/MCP connection: unavailable from current Work tools; not installed/deployed.

See `IMPLEMENTATION_STATUS.md` for per-component gaps. Do not cite this report as evidence that integration tests passed.
