# SEL 公開 HTML 書目擷取驗收

- 2026-11-24：工作環境實際讀取 PLOS 的 `robots.txt` 和一筆公開文章 HTML，兩者均為 HTTP 200。只輸出書目欄位，不下載 PDF、不存全文。
- 書目：Ashu, C. N., Hargreaves, D. S., Robinson, T., Nicholls, D., & Ram, B. (2025). *“I think it is our responsibility, but not solely our responsibility”: A qualitative study exploring teachers’ perspectives on promoting mental health in Northwest London primary schools*. PLOS ONE, 20(12), e0336946. https://doi.org/10.1371/journal.pone.0336946
- 證據：[PLOS 明示非大量文章 HTML 可用於資料探勘](https://api.plos.org/text-and-data-mining.html)、[使用條款](https://plos.org/terms-of-use/)、[robots.txt](https://journals.plos.org/robots.txt)、[文章頁及 CC BY 說明](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0336946)。robots 規定 Crawl-delay: 30；文章路徑未命中 Disallow。這篇以全校心理健康政策推動為主，內含課程 SEL、領導管理、教職員培力等校務面向，不是 SEL 介入成效研究。
- 範圍：此版本只允許上述已人工審閱的精確 URL；不接受使用者任填目標、跳轉、付費牆或 CAPTCHA。robots 在首次擷取或過期後以原站重新檢查；各執行程序的文章請求最少間隔 30 秒並快取 24 小時。若需正式部署，維持單一工作程序，勿多開以乘倍放大流量；增加來源前重新查核網站政策和文章授權。來源政策變更須人工重新審閱。
- 測試：`python -m unittest discover -s tests -p test_sel_crawler.py -v` 使用替身測正向解析與禁止路徑、失敗規則、拒絕存取、禁止跳轉、驗證頁、DOI 不符、限速、快取等。網路實測與替身測試分開。
