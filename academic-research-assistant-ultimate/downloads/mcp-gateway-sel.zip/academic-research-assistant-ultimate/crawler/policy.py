"""Conservative URL and source policy primitives."""
from urllib.parse import urlparse
import ipaddress,socket
ALLOWED_SCHEMES={"https"}
def check_url(url:str,allowed_hosts:set[str]):
    u=urlparse(url)
    if u.scheme not in ALLOWED_SCHEMES or not u.hostname: raise ValueError("HTTPS URL required")
    host=u.hostname.lower()
    if host not in allowed_hosts: raise ValueError("Host not allowlisted")
    if u.username or u.password: raise ValueError("Credentials in URL forbidden")
    try:
        for item in socket.getaddrinfo(host,None):
            ip=ipaddress.ip_address(item[4][0])
            if not ip.is_global: raise ValueError("Non-public destination blocked")
    except socket.gaierror as e: raise ValueError("DNS resolution failed") from e
    return True
def response_policy(status:int):
    if status in (403,429): return "stop_and_report"
    return "continue" if 200<=status<300 else "record_error"
