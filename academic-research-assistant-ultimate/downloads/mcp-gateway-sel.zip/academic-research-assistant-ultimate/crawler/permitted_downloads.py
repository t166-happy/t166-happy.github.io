"""Download only explicitly authorized OA URLs; no arbitrary page crawling."""
import hashlib,os,httpx
async def download(url:str,license_id:str,source_url:str,dest:str):
    if not license_id: raise PermissionError("Missing explicit license/permission evidence")
    if not url.startswith("https://"): raise ValueError("HTTPS required")
    async with httpx.AsyncClient(timeout=60,follow_redirects=False) as c:
        r=await c.get(url); r.raise_for_status()
        data=r.content
    if not data.startswith(b"%PDF-"): raise ValueError("Downloaded content is not PDF")
    os.makedirs(os.path.dirname(dest) or ".",exist_ok=True)
    with open(dest,"wb") as f:f.write(data)
    return {"path":dest,"sha256":hashlib.sha256(data).hexdigest(),"license":license_id,"source_url":source_url,"bytes":len(data)}
