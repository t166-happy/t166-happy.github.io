"""One explicitly permitted, low-volume public bibliographic crawler.

Caller-controlled values never become outbound request destinations. The source
registry contains exact HTTPS URLs, not host suffixes or arbitrary patterns.
No login, cookies, redirects, PDFs, files, crawling queues or link traversal.
"""
from __future__ import annotations

import asyncio
import copy
import re
import threading
import time
from dataclasses import asdict, dataclass
from html.parser import HTMLParser
from urllib.error import HTTPError, URLError
from urllib.parse import unquote, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

USER_AGENT = "AcademicResearchAssistant/0.2"
ROBOTS_LIMIT = 64 * 1024
HTML_LIMIT = 2 * 1024 * 1024
CACHE_TTL = 24 * 60 * 60
LIVE_TEST_URL = "https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0336946"


@dataclass(frozen=True)
class Source:
    url: str
    doi: str
    robots_url: str
    terms_url: str
    permission_url: str
    permission_reviewed: str
    minimum_interval_seconds: int
    recorded_article_license: str


_PLOS = Source(
    LIVE_TEST_URL, "10.1371/journal.pone.0336946",
    "https://journals.plos.org/robots.txt",
    "https://plos.org/terms-of-use/",
    "https://api.plos.org/text-and-data-mining.html",
    "2026-11-24", 30, "CC BY (publisher article page)",
)
_SOURCES = {source.url: source for source in (_PLOS,)}


def inspect_source_policy(url: str) -> dict:
    """Return registry evidence; does not certify robots availability."""
    source = _SOURCES.get(url)
    if source is None:
        return {"status": "blocked", "reason": "URL_NOT_ALLOWLISTED"}
    return {
        "status": "registered", "scope": "single public HTML bibliography only",
        "robots": "live check required before first article request (24h TTL)",
        **asdict(source),
    }


class _NoRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _fetch(url: str, limit: int, accept: str) -> tuple[int, str, bytes]:
    """Fetch one fixed HTTPS target using the environment's normal egress."""
    opener = build_opener(_NoRedirects())
    request = Request(url, headers={
        "User-Agent": USER_AGENT, "Accept": accept, "Accept-Encoding": "identity",
    })
    try:
        with opener.open(request, timeout=12) as response:
            mime = response.headers.get_content_type()
            if mime not in accept.split(","):
                return response.status, mime, b""
            if response.headers.get("Content-Encoding", "identity").lower() != "identity":
                return response.status, mime, b""
            return response.status, mime, response.read(limit + 1)
    except HTTPError as error:
        try:
            return error.code, "", b""
        finally:
            error.close()


def _robots(robots_url: str, target_url: str, body: bytes) -> tuple[bool, int]:
    """Conservative subset: any matching Disallow wins; ambiguity denies.

    Inspect all advertised user-agent rules conservatively. This may reject a
    URL another crawler would allow, but it cannot use a more permissive agent
    group or an Allow override to bypass a matching Disallow.
    """
    if len(body) > ROBOTS_LIMIT or not body:
        raise ValueError("Invalid robots size")
    content = body.decode("utf-8-sig")
    if "<html" in content.lower() or "\x00" in content:
        raise ValueError("Invalid robots response")
    target = urlsplit(target_url)
    if urlsplit(robots_url).netloc != target.netloc:
        raise ValueError("Robots origin mismatch")
    path = unquote(target.path + (("?" + target.query) if target.query else ""))
    has_agent = False
    blocked = False
    delay = 0
    for raw in content.splitlines():
        entry = raw.split("#", 1)[0].strip()
        if not entry:
            continue
        name, sep, value = entry.partition(":")
        if not sep:
            raise ValueError("Invalid robots directive")
        name, value = name.strip().lower(), value.strip()
        if name == "user-agent" and value:
            has_agent = True
        if name == "crawl-delay" and value:
            if not re.fullmatch(r"[0-9]{1,4}(\.[0-9]{1,3})?", value):
                raise ValueError("Invalid crawl-delay")
            delay = max(delay, int(float(value) + .9999))
        if name == "disallow" and value:
            # PLOS rules include leading wildcards, so do not use Python
            # versions of robotparser that treat '*' as a literal character.
            value = unquote(value)
            if len(value) > 512 or value.count("*") > 4:
                raise ValueError("Robots rule too complex for safe evaluation")
            terminal = value.endswith("$")
            value = value[:-1] if terminal else value
            pattern = ".*".join(re.escape(item) for item in value.split("*"))
            blocked |= re.match(pattern + (r"\Z" if terminal else ""), path) is not None
    if not has_agent:
        raise ValueError("No recognized robots policy")
    return not blocked, delay


_CITATIONS = {
    "citation_title", "citation_author", "citation_publication_date",
    "citation_date", "citation_journal_title", "citation_doi",
    "citation_volume", "citation_issue", "citation_firstpage",
    "citation_lastpage",
}


class _CitationParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.meta: dict[str, list[str]] = {}
        self._in_title = False
        self.title = ""

    def handle_starttag(self, tag, attrs):
        if tag == "title":
            self._in_title = True
        if tag != "meta":
            return
        values = {key: value or "" for key, value in attrs}
        name = values.get("name", "").strip().lower()
        content = " ".join(values.get("content", "").split())[:500]
        if name in _CITATIONS and content:
            items = self.meta.setdefault(name, [])
            if len(items) < 100:
                items.append(content)

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False

    def handle_data(self, data):
        if self._in_title and len(self.title) < 500:
            self.title += data[:500]


def _record(body: bytes, source: Source) -> dict | None:
    if not body or len(body) > HTML_LIMIT:
        return None
    parser = _CitationParser()
    parser.feed(body.decode("utf-8", "replace"))
    parser.close()

    def field(name):
        return next(iter(parser.meta.get("citation_" + name, [])), None)

    if re.search(r"captcha|verify you are human|access denied|just a moment|sign in|log in",
                 parser.title, flags=re.IGNORECASE):
        return None
    if not field("title") or (field("doi") or "").strip().lower() != source.doi:
        return None
    return {
        "title": field("title"), "doi": source.doi,
        "authors": list(dict.fromkeys(parser.meta.get("citation_author", []))),
        "published": field("publication_date") or field("date"),
        "journal": field("journal_title"),
        "volume": field("volume"), "issue": field("issue"),
        "first_page": field("firstpage"), "last_page": field("lastpage"),
        "source_url": source.url, "license_evidence": source.recorded_article_license,
        "external_untrusted_metadata": True,
    }


class _Crawler:
    def __init__(self, *, fetch=_fetch, clock=time.monotonic):
        self.fetch, self.clock = fetch, clock
        self.lock = threading.Lock()
        self.robots_cache: dict[str, tuple[float, int]] = {}
        self.next_allowed: dict[str, float] = {}
        self.robots_failures: dict[str, tuple[float, dict]] = {}
        self.records: dict[str, tuple[float, dict]] = {}
        self.stopped: dict[str, str] = {}

    def crawl(self, url: str) -> dict:
        def blocked(reason, stage=None, **details):
            return {"status": "blocked", "reason": reason,
                    **({"stage": stage} if stage else {}), **details}

        source = _SOURCES.get(url)
        if source is None:
            return blocked("URL_NOT_ALLOWLISTED")
        host = urlsplit(source.url).hostname
        with self.lock:
            if host in self.stopped:
                return blocked("SOURCE_STOPPED", prior_reason=self.stopped[host])
            now = self.clock()
            rules = self.robots_cache.get(source.url)
            if rules is None or now >= rules[0]:
                rejected = self.robots_failures.get(source.url)
                if rejected and now < rejected[0]:
                    return dict(rejected[1])

                def block_robots(reason, ttl, **details):
                    result = blocked(reason, "robots", **details)
                    self.robots_failures[source.url] = (self.clock() + ttl, result)
                    return dict(result)

                try:
                    status, mime, body = self.fetch(source.robots_url, ROBOTS_LIMIT, "text/plain")
                    if status != 200 or mime != "text/plain":
                        if status in {401, 403, 429}:
                            self.stopped[host] = f"HTTP_{status}"
                        return block_robots(
                            "ROBOTS_UNAVAILABLE", source.minimum_interval_seconds, http_status=status
                        )
                    permitted, delay = _robots(source.robots_url, source.url, body)
                except (OSError, URLError, UnicodeError, ValueError):
                    return block_robots("ROBOTS_UNAVAILABLE", source.minimum_interval_seconds)
                if not permitted:
                    return block_robots("ROBOTS_DISALLOWED", CACHE_TTL, http_status=200)
                rules = (self.clock() + CACHE_TTL, max(delay, source.minimum_interval_seconds))
                self.robots_cache[source.url] = rules

            now = self.clock()
            record = self.records.get(source.url)
            if record and now < record[0]:
                return {**copy.deepcopy(record[1]), "cache": True}
            if now < self.next_allowed.get(host, 0):
                return blocked("LOCAL_RATE_LIMIT", "article")
            try:
                status, mime, body = self.fetch(source.url, HTML_LIMIT, "text/html,application/xhtml+xml")
            except (OSError, URLError, ValueError):
                return blocked("ARTICLE_UNAVAILABLE", "article")
            finally:
                self.next_allowed[host] = self.clock() + rules[1]
            if status in {401, 403, 429}:
                self.stopped[host] = f"HTTP_{status}"
                return blocked("REMOTE_ACCESS_STOP", "article", http_status=status)
            if 300 <= status < 400:
                return blocked("REDIRECT_NOT_FOLLOWED", "article", http_status=status)
            if status != 200 or mime not in {"text/html", "application/xhtml+xml"}:
                return blocked("ARTICLE_UNAVAILABLE", "article", http_status=status)
            record = _record(body, source)
            if record is None:
                self.stopped[host] = "METADATA_NOT_VERIFIED"
                return blocked("METADATA_NOT_VERIFIED", "article", http_status=200)
            result = {"status": "ok", "record": record, "cache": False,
                      "http_status": 200, "robots_http_status": 200,
                      "minimum_interval_seconds": rules[1]}
            self.records[source.url] = (self.clock() + CACHE_TTL, copy.deepcopy(result))
            return result


_crawler = _Crawler()


async def crawl_public_bibliography(url: str) -> dict:
    """Return bounded citation fields from the registered public page only."""
    return await asyncio.to_thread(_crawler.crawl, url)
