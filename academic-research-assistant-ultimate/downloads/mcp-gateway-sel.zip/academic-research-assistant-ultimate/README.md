# Academic Research Assistant Ultimate

繁體中文學術文獻研究 Skill 與獨立 MCP Gateway 專案。Skill 是提示/工作流程包；Gateway 是需另行部署並設定連線的服務。此版 Gateway 已做本機短時啟動，未發布為常駐服務，也未掛載至 ChatGPT 帳號。請先讀本次的 [SEL 驗收報告](evidence/SEL-VALIDATION.md)。

## 快速使用
1. 將 `SKILL.md` 與 `references/` 安裝到支援本地 Skills 的執行環境。
2. Python 3.11+；`pip install -r requirements.txt`。
3. 設定 `.env.example` 中需要的環境變數（不要把秘密提交到 Git）。
4. CLI connector 可直接 import；MCP 啟動：`python -m gateway.server`。
5. 開啟正式對外服務前必須部署 HTTPS/OAuth 並完成安全檢查。

## 來源狀態
OpenAlex REST、Crossref REST、Semantic Scholar、Unpaywall、ERIC、Europe PMC、NDLTD CSV connector 已實作；是否能連線取決於目前網路與憑證。Airiti、臺灣期刊文獻資訊網、TCI-HSS 為明確停用的 adapter。官方 OpenAlex MCP 並未連接本服務。

## 限制
Gateway MVP 目前提供搜尋、DOI 查核、來源狀態，以及單一許可來源的公開 HTML 書目擷取工具；完整要求中其他工具在 `IMPLEMENTATION_STATUS.md` 列為未實作/未授權，不能視為已通過驗收。請勿對付費/登入來源爬取或未授權下載。
